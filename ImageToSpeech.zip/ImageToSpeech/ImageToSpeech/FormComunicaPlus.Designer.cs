﻿namespace ImageToSpeech
{
    partial class FormComunicaPlus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormComunicaPlus));
            this.buttonAveces = new System.Windows.Forms.Button();
            this.buttonNo = new System.Windows.Forms.Button();
            this.buttonSi = new System.Windows.Forms.Button();
            this.buttonAtras = new System.Windows.Forms.Button();
            this.buttonA = new System.Windows.Forms.Button();
            this.buttonE = new System.Windows.Forms.Button();
            this.buttonI = new System.Windows.Forms.Button();
            this.buttonO = new System.Windows.Forms.Button();
            this.buttonU = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button0 = new System.Windows.Forms.Button();
            this.buttonG = new System.Windows.Forms.Button();
            this.buttonF = new System.Windows.Forms.Button();
            this.buttonD = new System.Windows.Forms.Button();
            this.buttonC = new System.Windows.Forms.Button();
            this.buttonB = new System.Windows.Forms.Button();
            this.buttonM = new System.Windows.Forms.Button();
            this.buttonL = new System.Windows.Forms.Button();
            this.buttonK = new System.Windows.Forms.Button();
            this.buttonJ = new System.Windows.Forms.Button();
            this.buttonH = new System.Windows.Forms.Button();
            this.buttonR = new System.Windows.Forms.Button();
            this.buttonQ = new System.Windows.Forms.Button();
            this.buttonP = new System.Windows.Forms.Button();
            this.buttonÑ = new System.Windows.Forms.Button();
            this.buttonN = new System.Windows.Forms.Button();
            this.buttonW = new System.Windows.Forms.Button();
            this.buttonV = new System.Windows.Forms.Button();
            this.buttonT = new System.Windows.Forms.Button();
            this.buttonS = new System.Windows.Forms.Button();
            this.buttonZ = new System.Windows.Forms.Button();
            this.buttonY = new System.Windows.Forms.Button();
            this.buttonX = new System.Windows.Forms.Button();
            this.textBox = new System.Windows.Forms.TextBox();
            this.buttonDOT = new System.Windows.Forms.Button();
            this.buttonCOMMA = new System.Windows.Forms.Button();
            this.buttonLEFTQUEST = new System.Windows.Forms.Button();
            this.buttonRIGHTQUEST = new System.Windows.Forms.Button();
            this.buttonLEFTEXCL = new System.Windows.Forms.Button();
            this.buttonRIGHTEXCL = new System.Windows.Forms.Button();
            this.buttonLEER = new System.Windows.Forms.Button();
            this.buttonSEMICOLON = new System.Windows.Forms.Button();
            this.buttonBORRAR = new System.Windows.Forms.Button();
            this.buttonSPACE = new System.Windows.Forms.Button();
            this.buttonCOLON = new System.Windows.Forms.Button();
            this.buttonInicio = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonAveces
            // 
            this.buttonAveces.AccessibleDescription = "Aveces";
            this.buttonAveces.AccessibleName = "Aveces";
            this.buttonAveces.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonAveces.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonAveces.BackgroundImage = global::ImageToSpeech.Properties.Resources.aVeces;
            this.buttonAveces.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonAveces.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonAveces.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAveces.Location = new System.Drawing.Point(95, 460);
            this.buttonAveces.Name = "buttonAveces";
            this.buttonAveces.Size = new System.Drawing.Size(103, 46);
            this.buttonAveces.TabIndex = 29;
            this.buttonAveces.UseVisualStyleBackColor = true;
            this.buttonAveces.Click += new System.EventHandler(this.buttonAveces_Click);
            // 
            // buttonNo
            // 
            this.buttonNo.AccessibleDescription = "No";
            this.buttonNo.AccessibleName = "No";
            this.buttonNo.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonNo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonNo.BackgroundImage = global::ImageToSpeech.Properties.Resources.no;
            this.buttonNo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonNo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonNo.Location = new System.Drawing.Point(213, 460);
            this.buttonNo.Name = "buttonNo";
            this.buttonNo.Size = new System.Drawing.Size(61, 46);
            this.buttonNo.TabIndex = 28;
            this.buttonNo.UseVisualStyleBackColor = true;
            this.buttonNo.Click += new System.EventHandler(this.buttonNo_Click);
            // 
            // buttonSi
            // 
            this.buttonSi.AccessibleDescription = "Si";
            this.buttonSi.AccessibleName = "Si";
            this.buttonSi.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonSi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonSi.BackgroundImage = global::ImageToSpeech.Properties.Resources.si;
            this.buttonSi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonSi.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonSi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSi.Location = new System.Drawing.Point(15, 460);
            this.buttonSi.Name = "buttonSi";
            this.buttonSi.Size = new System.Drawing.Size(62, 46);
            this.buttonSi.TabIndex = 27;
            this.buttonSi.UseVisualStyleBackColor = true;
            this.buttonSi.Click += new System.EventHandler(this.buttonSi_Click);
            // 
            // buttonAtras
            // 
            this.buttonAtras.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonAtras.BackgroundImage = global::ImageToSpeech.Properties.Resources.back;
            this.buttonAtras.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonAtras.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonAtras.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAtras.Location = new System.Drawing.Point(2, 2);
            this.buttonAtras.Name = "buttonAtras";
            this.buttonAtras.Size = new System.Drawing.Size(99, 30);
            this.buttonAtras.TabIndex = 30;
            this.buttonAtras.Text = "Confort 2";
            this.buttonAtras.UseVisualStyleBackColor = true;
            this.buttonAtras.Click += new System.EventHandler(this.buttonAtras_Click);
            // 
            // buttonA
            // 
            this.buttonA.AccessibleDescription = "A";
            this.buttonA.AccessibleName = "A";
            this.buttonA.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonA.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonA.Location = new System.Drawing.Point(17, 92);
            this.buttonA.Name = "buttonA";
            this.buttonA.Size = new System.Drawing.Size(35, 39);
            this.buttonA.TabIndex = 31;
            this.buttonA.Text = "A";
            this.buttonA.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonA.UseVisualStyleBackColor = true;
            this.buttonA.Click += new System.EventHandler(this.buttonA_Click);
            // 
            // buttonE
            // 
            this.buttonE.AccessibleDescription = "E";
            this.buttonE.AccessibleName = "E";
            this.buttonE.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonE.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonE.Location = new System.Drawing.Point(58, 92);
            this.buttonE.Name = "buttonE";
            this.buttonE.Size = new System.Drawing.Size(35, 39);
            this.buttonE.TabIndex = 32;
            this.buttonE.Text = "E";
            this.buttonE.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonE.UseVisualStyleBackColor = true;
            this.buttonE.Click += new System.EventHandler(this.buttonE_Click);
            // 
            // buttonI
            // 
            this.buttonI.AccessibleDescription = "I";
            this.buttonI.AccessibleName = "I";
            this.buttonI.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonI.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonI.Location = new System.Drawing.Point(100, 92);
            this.buttonI.Name = "buttonI";
            this.buttonI.Size = new System.Drawing.Size(35, 39);
            this.buttonI.TabIndex = 33;
            this.buttonI.Text = "I";
            this.buttonI.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonI.UseVisualStyleBackColor = true;
            this.buttonI.Click += new System.EventHandler(this.buttonI_Click);
            // 
            // buttonO
            // 
            this.buttonO.AccessibleDescription = "O";
            this.buttonO.AccessibleName = "O";
            this.buttonO.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonO.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonO.Location = new System.Drawing.Point(141, 92);
            this.buttonO.Name = "buttonO";
            this.buttonO.Size = new System.Drawing.Size(35, 39);
            this.buttonO.TabIndex = 34;
            this.buttonO.Text = "O";
            this.buttonO.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonO.UseVisualStyleBackColor = true;
            this.buttonO.Click += new System.EventHandler(this.buttonO_Click);
            // 
            // buttonU
            // 
            this.buttonU.AccessibleDescription = "U";
            this.buttonU.AccessibleName = "U";
            this.buttonU.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonU.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonU.Location = new System.Drawing.Point(182, 92);
            this.buttonU.Name = "buttonU";
            this.buttonU.Size = new System.Drawing.Size(35, 39);
            this.buttonU.TabIndex = 35;
            this.buttonU.Text = "U";
            this.buttonU.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonU.UseVisualStyleBackColor = true;
            this.buttonU.Click += new System.EventHandler(this.buttonU_Click);
            // 
            // button1
            // 
            this.button1.AccessibleDescription = "1";
            this.button1.AccessibleName = "1";
            this.button1.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(250, 52);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(35, 39);
            this.button1.TabIndex = 36;
            this.button1.Text = "1";
            this.button1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.AccessibleDescription = "2";
            this.button2.AccessibleName = "2";
            this.button2.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(250, 97);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(35, 39);
            this.button2.TabIndex = 37;
            this.button2.Text = "2";
            this.button2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.AccessibleDescription = "3";
            this.button3.AccessibleName = "3";
            this.button3.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(250, 142);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(35, 39);
            this.button3.TabIndex = 38;
            this.button3.Text = "3";
            this.button3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.AccessibleDescription = "4";
            this.button4.AccessibleName = "4";
            this.button4.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(250, 187);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(35, 39);
            this.button4.TabIndex = 39;
            this.button4.Text = "4";
            this.button4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.AccessibleDescription = "5";
            this.button5.AccessibleName = "5";
            this.button5.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(250, 232);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(35, 39);
            this.button5.TabIndex = 40;
            this.button5.Text = "5";
            this.button5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.AccessibleDescription = "6";
            this.button6.AccessibleName = "6";
            this.button6.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(249, 277);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(35, 39);
            this.button6.TabIndex = 41;
            this.button6.Text = "6";
            this.button6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.AccessibleDescription = "7";
            this.button7.AccessibleName = "7";
            this.button7.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(249, 322);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(35, 39);
            this.button7.TabIndex = 42;
            this.button7.Text = "7";
            this.button7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.AccessibleDescription = "8";
            this.button8.AccessibleName = "8";
            this.button8.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(249, 367);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(35, 39);
            this.button8.TabIndex = 43;
            this.button8.Text = "8";
            this.button8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.AccessibleDescription = "9";
            this.button9.AccessibleName = "9";
            this.button9.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(249, 412);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(35, 39);
            this.button9.TabIndex = 44;
            this.button9.Text = "9";
            this.button9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button0
            // 
            this.button0.AccessibleDescription = "0";
            this.button0.AccessibleName = "0";
            this.button0.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.button0.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button0.Location = new System.Drawing.Point(250, 8);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(35, 39);
            this.button0.TabIndex = 45;
            this.button0.Text = "0";
            this.button0.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button0.UseVisualStyleBackColor = true;
            this.button0.Click += new System.EventHandler(this.button0_Click);
            // 
            // buttonG
            // 
            this.buttonG.AccessibleDescription = "U";
            this.buttonG.AccessibleName = "U";
            this.buttonG.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonG.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonG.Location = new System.Drawing.Point(182, 137);
            this.buttonG.Name = "buttonG";
            this.buttonG.Size = new System.Drawing.Size(35, 39);
            this.buttonG.TabIndex = 50;
            this.buttonG.Text = "G";
            this.buttonG.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonG.UseVisualStyleBackColor = true;
            this.buttonG.Click += new System.EventHandler(this.buttonG_Click);
            // 
            // buttonF
            // 
            this.buttonF.AccessibleDescription = "O";
            this.buttonF.AccessibleName = "O";
            this.buttonF.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonF.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonF.Location = new System.Drawing.Point(141, 137);
            this.buttonF.Name = "buttonF";
            this.buttonF.Size = new System.Drawing.Size(35, 39);
            this.buttonF.TabIndex = 49;
            this.buttonF.Text = "F";
            this.buttonF.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonF.UseVisualStyleBackColor = true;
            this.buttonF.Click += new System.EventHandler(this.buttonF_Click);
            // 
            // buttonD
            // 
            this.buttonD.AccessibleDescription = "I";
            this.buttonD.AccessibleName = "I";
            this.buttonD.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonD.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonD.Location = new System.Drawing.Point(100, 137);
            this.buttonD.Name = "buttonD";
            this.buttonD.Size = new System.Drawing.Size(35, 39);
            this.buttonD.TabIndex = 48;
            this.buttonD.Text = "D";
            this.buttonD.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonD.UseVisualStyleBackColor = true;
            this.buttonD.Click += new System.EventHandler(this.buttonD_Click);
            // 
            // buttonC
            // 
            this.buttonC.AccessibleDescription = "E";
            this.buttonC.AccessibleName = "E";
            this.buttonC.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonC.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonC.Location = new System.Drawing.Point(58, 137);
            this.buttonC.Name = "buttonC";
            this.buttonC.Size = new System.Drawing.Size(35, 39);
            this.buttonC.TabIndex = 47;
            this.buttonC.Text = "C";
            this.buttonC.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonC.UseVisualStyleBackColor = true;
            this.buttonC.Click += new System.EventHandler(this.buttonC_Click);
            // 
            // buttonB
            // 
            this.buttonB.AccessibleDescription = "A";
            this.buttonB.AccessibleName = "A";
            this.buttonB.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonB.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonB.Location = new System.Drawing.Point(17, 137);
            this.buttonB.Name = "buttonB";
            this.buttonB.Size = new System.Drawing.Size(35, 39);
            this.buttonB.TabIndex = 46;
            this.buttonB.Text = "B";
            this.buttonB.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonB.UseVisualStyleBackColor = true;
            this.buttonB.Click += new System.EventHandler(this.buttonB_Click);
            // 
            // buttonM
            // 
            this.buttonM.AccessibleDescription = "U";
            this.buttonM.AccessibleName = "U";
            this.buttonM.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonM.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonM.Location = new System.Drawing.Point(182, 182);
            this.buttonM.Name = "buttonM";
            this.buttonM.Size = new System.Drawing.Size(35, 39);
            this.buttonM.TabIndex = 55;
            this.buttonM.Text = "M";
            this.buttonM.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonM.UseVisualStyleBackColor = true;
            this.buttonM.Click += new System.EventHandler(this.buttonM_Click);
            // 
            // buttonL
            // 
            this.buttonL.AccessibleDescription = "O";
            this.buttonL.AccessibleName = "O";
            this.buttonL.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonL.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonL.Location = new System.Drawing.Point(141, 182);
            this.buttonL.Name = "buttonL";
            this.buttonL.Size = new System.Drawing.Size(35, 39);
            this.buttonL.TabIndex = 54;
            this.buttonL.Text = "L";
            this.buttonL.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonL.UseVisualStyleBackColor = true;
            this.buttonL.Click += new System.EventHandler(this.buttonL_Click);
            // 
            // buttonK
            // 
            this.buttonK.AccessibleDescription = "I";
            this.buttonK.AccessibleName = "I";
            this.buttonK.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonK.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonK.Location = new System.Drawing.Point(100, 182);
            this.buttonK.Name = "buttonK";
            this.buttonK.Size = new System.Drawing.Size(35, 39);
            this.buttonK.TabIndex = 53;
            this.buttonK.Text = "K";
            this.buttonK.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonK.UseVisualStyleBackColor = true;
            this.buttonK.Click += new System.EventHandler(this.buttonK_Click);
            // 
            // buttonJ
            // 
            this.buttonJ.AccessibleDescription = "E";
            this.buttonJ.AccessibleName = "E";
            this.buttonJ.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonJ.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonJ.Location = new System.Drawing.Point(58, 182);
            this.buttonJ.Name = "buttonJ";
            this.buttonJ.Size = new System.Drawing.Size(35, 39);
            this.buttonJ.TabIndex = 52;
            this.buttonJ.Text = "J";
            this.buttonJ.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonJ.UseVisualStyleBackColor = true;
            this.buttonJ.Click += new System.EventHandler(this.buttonJ_Click);
            // 
            // buttonH
            // 
            this.buttonH.AccessibleDescription = "A";
            this.buttonH.AccessibleName = "A";
            this.buttonH.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonH.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonH.Location = new System.Drawing.Point(17, 182);
            this.buttonH.Name = "buttonH";
            this.buttonH.Size = new System.Drawing.Size(35, 39);
            this.buttonH.TabIndex = 51;
            this.buttonH.Text = "H";
            this.buttonH.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonH.UseVisualStyleBackColor = true;
            this.buttonH.Click += new System.EventHandler(this.buttonH_Click);
            // 
            // buttonR
            // 
            this.buttonR.AccessibleDescription = "U";
            this.buttonR.AccessibleName = "U";
            this.buttonR.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonR.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonR.Location = new System.Drawing.Point(182, 227);
            this.buttonR.Name = "buttonR";
            this.buttonR.Size = new System.Drawing.Size(35, 39);
            this.buttonR.TabIndex = 60;
            this.buttonR.Text = "R";
            this.buttonR.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonR.UseVisualStyleBackColor = true;
            this.buttonR.Click += new System.EventHandler(this.buttonR_Click);
            // 
            // buttonQ
            // 
            this.buttonQ.AccessibleDescription = "O";
            this.buttonQ.AccessibleName = "O";
            this.buttonQ.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonQ.Location = new System.Drawing.Point(141, 227);
            this.buttonQ.Name = "buttonQ";
            this.buttonQ.Size = new System.Drawing.Size(35, 39);
            this.buttonQ.TabIndex = 59;
            this.buttonQ.Text = "Q";
            this.buttonQ.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonQ.UseVisualStyleBackColor = true;
            this.buttonQ.Click += new System.EventHandler(this.buttonQ_Click);
            // 
            // buttonP
            // 
            this.buttonP.AccessibleDescription = "I";
            this.buttonP.AccessibleName = "I";
            this.buttonP.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonP.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonP.Location = new System.Drawing.Point(100, 227);
            this.buttonP.Name = "buttonP";
            this.buttonP.Size = new System.Drawing.Size(35, 39);
            this.buttonP.TabIndex = 58;
            this.buttonP.Text = "P";
            this.buttonP.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonP.UseVisualStyleBackColor = true;
            this.buttonP.Click += new System.EventHandler(this.buttonP_Click);
            // 
            // buttonÑ
            // 
            this.buttonÑ.AccessibleDescription = "E";
            this.buttonÑ.AccessibleName = "E";
            this.buttonÑ.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonÑ.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonÑ.Location = new System.Drawing.Point(58, 227);
            this.buttonÑ.Name = "buttonÑ";
            this.buttonÑ.Size = new System.Drawing.Size(35, 39);
            this.buttonÑ.TabIndex = 57;
            this.buttonÑ.Text = "Ñ";
            this.buttonÑ.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonÑ.UseVisualStyleBackColor = true;
            this.buttonÑ.Click += new System.EventHandler(this.buttonÑ_Click);
            // 
            // buttonN
            // 
            this.buttonN.AccessibleDescription = "A";
            this.buttonN.AccessibleName = "A";
            this.buttonN.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonN.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonN.Location = new System.Drawing.Point(17, 227);
            this.buttonN.Name = "buttonN";
            this.buttonN.Size = new System.Drawing.Size(35, 39);
            this.buttonN.TabIndex = 56;
            this.buttonN.Text = "N";
            this.buttonN.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonN.UseVisualStyleBackColor = true;
            this.buttonN.Click += new System.EventHandler(this.buttonN_Click);
            // 
            // buttonW
            // 
            this.buttonW.AccessibleDescription = "U";
            this.buttonW.AccessibleName = "U";
            this.buttonW.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonW.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonW.Location = new System.Drawing.Point(141, 272);
            this.buttonW.Name = "buttonW";
            this.buttonW.Size = new System.Drawing.Size(35, 39);
            this.buttonW.TabIndex = 65;
            this.buttonW.Text = "W";
            this.buttonW.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonW.UseVisualStyleBackColor = true;
            this.buttonW.Click += new System.EventHandler(this.buttonW_Click);
            // 
            // buttonV
            // 
            this.buttonV.AccessibleDescription = "O";
            this.buttonV.AccessibleName = "O";
            this.buttonV.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonV.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonV.Location = new System.Drawing.Point(100, 272);
            this.buttonV.Name = "buttonV";
            this.buttonV.Size = new System.Drawing.Size(35, 39);
            this.buttonV.TabIndex = 64;
            this.buttonV.Text = "V";
            this.buttonV.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonV.UseVisualStyleBackColor = true;
            this.buttonV.Click += new System.EventHandler(this.buttonV_Click);
            // 
            // buttonT
            // 
            this.buttonT.AccessibleDescription = "E";
            this.buttonT.AccessibleName = "E";
            this.buttonT.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonT.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonT.Location = new System.Drawing.Point(58, 272);
            this.buttonT.Name = "buttonT";
            this.buttonT.Size = new System.Drawing.Size(35, 39);
            this.buttonT.TabIndex = 62;
            this.buttonT.Text = "T";
            this.buttonT.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonT.UseVisualStyleBackColor = true;
            this.buttonT.Click += new System.EventHandler(this.buttonT_Click);
            // 
            // buttonS
            // 
            this.buttonS.AccessibleDescription = "A";
            this.buttonS.AccessibleName = "A";
            this.buttonS.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonS.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonS.Location = new System.Drawing.Point(17, 272);
            this.buttonS.Name = "buttonS";
            this.buttonS.Size = new System.Drawing.Size(35, 39);
            this.buttonS.TabIndex = 61;
            this.buttonS.Text = "S";
            this.buttonS.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonS.UseVisualStyleBackColor = true;
            this.buttonS.Click += new System.EventHandler(this.buttonS_Click);
            // 
            // buttonZ
            // 
            this.buttonZ.AccessibleDescription = "I";
            this.buttonZ.AccessibleName = "I";
            this.buttonZ.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonZ.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonZ.Location = new System.Drawing.Point(59, 317);
            this.buttonZ.Name = "buttonZ";
            this.buttonZ.Size = new System.Drawing.Size(35, 39);
            this.buttonZ.TabIndex = 68;
            this.buttonZ.Text = "Z";
            this.buttonZ.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonZ.UseVisualStyleBackColor = true;
            this.buttonZ.Click += new System.EventHandler(this.buttonZ_Click);
            // 
            // buttonY
            // 
            this.buttonY.AccessibleDescription = "E";
            this.buttonY.AccessibleName = "E";
            this.buttonY.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonY.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonY.Location = new System.Drawing.Point(17, 317);
            this.buttonY.Name = "buttonY";
            this.buttonY.Size = new System.Drawing.Size(35, 39);
            this.buttonY.TabIndex = 67;
            this.buttonY.Text = "Y";
            this.buttonY.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonY.UseVisualStyleBackColor = true;
            this.buttonY.Click += new System.EventHandler(this.buttonY_Click);
            // 
            // buttonX
            // 
            this.buttonX.AccessibleDescription = "A";
            this.buttonX.AccessibleName = "A";
            this.buttonX.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonX.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonX.Location = new System.Drawing.Point(182, 272);
            this.buttonX.Name = "buttonX";
            this.buttonX.Size = new System.Drawing.Size(35, 39);
            this.buttonX.TabIndex = 66;
            this.buttonX.Text = "X";
            this.buttonX.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonX.UseVisualStyleBackColor = true;
            this.buttonX.Click += new System.EventHandler(this.buttonX_Click);
            // 
            // textBox
            // 
            this.textBox.Cursor = System.Windows.Forms.Cursors.No;
            this.textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F);
            this.textBox.Location = new System.Drawing.Point(18, 50);
            this.textBox.Name = "textBox";
            this.textBox.ReadOnly = true;
            this.textBox.Size = new System.Drawing.Size(199, 35);
            this.textBox.TabIndex = 69;
            this.textBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // buttonDOT
            // 
            this.buttonDOT.AccessibleDescription = "I";
            this.buttonDOT.AccessibleName = "I";
            this.buttonDOT.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonDOT.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.buttonDOT.Location = new System.Drawing.Point(100, 317);
            this.buttonDOT.Name = "buttonDOT";
            this.buttonDOT.Size = new System.Drawing.Size(24, 39);
            this.buttonDOT.TabIndex = 70;
            this.buttonDOT.Text = ".";
            this.buttonDOT.UseVisualStyleBackColor = true;
            this.buttonDOT.Click += new System.EventHandler(this.buttonDOT_Click);
            // 
            // buttonCOMMA
            // 
            this.buttonCOMMA.AccessibleDescription = "I";
            this.buttonCOMMA.AccessibleName = "I";
            this.buttonCOMMA.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonCOMMA.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.buttonCOMMA.Location = new System.Drawing.Point(131, 317);
            this.buttonCOMMA.Name = "buttonCOMMA";
            this.buttonCOMMA.Size = new System.Drawing.Size(24, 39);
            this.buttonCOMMA.TabIndex = 71;
            this.buttonCOMMA.Text = ",";
            this.buttonCOMMA.UseVisualStyleBackColor = true;
            this.buttonCOMMA.Click += new System.EventHandler(this.buttonCOMMA_Click);
            // 
            // buttonLEFTQUEST
            // 
            this.buttonLEFTQUEST.AccessibleDescription = "I";
            this.buttonLEFTQUEST.AccessibleName = "I";
            this.buttonLEFTQUEST.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonLEFTQUEST.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.buttonLEFTQUEST.Location = new System.Drawing.Point(162, 377);
            this.buttonLEFTQUEST.Name = "buttonLEFTQUEST";
            this.buttonLEFTQUEST.Size = new System.Drawing.Size(24, 30);
            this.buttonLEFTQUEST.TabIndex = 72;
            this.buttonLEFTQUEST.Text = "¿";
            this.buttonLEFTQUEST.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonLEFTQUEST.UseVisualStyleBackColor = true;
            this.buttonLEFTQUEST.Click += new System.EventHandler(this.buttonLEFTQUEST_Click);
            // 
            // buttonRIGHTQUEST
            // 
            this.buttonRIGHTQUEST.AccessibleDescription = "I";
            this.buttonRIGHTQUEST.AccessibleName = "I";
            this.buttonRIGHTQUEST.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonRIGHTQUEST.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.buttonRIGHTQUEST.Location = new System.Drawing.Point(193, 377);
            this.buttonRIGHTQUEST.Name = "buttonRIGHTQUEST";
            this.buttonRIGHTQUEST.Size = new System.Drawing.Size(24, 30);
            this.buttonRIGHTQUEST.TabIndex = 73;
            this.buttonRIGHTQUEST.Text = "?";
            this.buttonRIGHTQUEST.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonRIGHTQUEST.UseVisualStyleBackColor = true;
            this.buttonRIGHTQUEST.Click += new System.EventHandler(this.buttonRIGHTQUEST_Click);
            // 
            // buttonLEFTEXCL
            // 
            this.buttonLEFTEXCL.AccessibleDescription = "I";
            this.buttonLEFTEXCL.AccessibleName = "I";
            this.buttonLEFTEXCL.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonLEFTEXCL.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.buttonLEFTEXCL.Location = new System.Drawing.Point(162, 347);
            this.buttonLEFTEXCL.Name = "buttonLEFTEXCL";
            this.buttonLEFTEXCL.Size = new System.Drawing.Size(24, 30);
            this.buttonLEFTEXCL.TabIndex = 74;
            this.buttonLEFTEXCL.Text = "¡";
            this.buttonLEFTEXCL.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonLEFTEXCL.UseVisualStyleBackColor = true;
            this.buttonLEFTEXCL.Click += new System.EventHandler(this.buttonLEFTEXCL_Click);
            // 
            // buttonRIGHTEXCL
            // 
            this.buttonRIGHTEXCL.AccessibleDescription = "I";
            this.buttonRIGHTEXCL.AccessibleName = "I";
            this.buttonRIGHTEXCL.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonRIGHTEXCL.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.buttonRIGHTEXCL.Location = new System.Drawing.Point(193, 347);
            this.buttonRIGHTEXCL.Name = "buttonRIGHTEXCL";
            this.buttonRIGHTEXCL.Size = new System.Drawing.Size(24, 30);
            this.buttonRIGHTEXCL.TabIndex = 75;
            this.buttonRIGHTEXCL.Text = "!";
            this.buttonRIGHTEXCL.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonRIGHTEXCL.UseVisualStyleBackColor = true;
            this.buttonRIGHTEXCL.Click += new System.EventHandler(this.buttonRIGHTEXCL_Click);
            // 
            // buttonLEER
            // 
            this.buttonLEER.AccessibleDescription = "I";
            this.buttonLEER.AccessibleName = "I";
            this.buttonLEER.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonLEER.BackgroundImage = global::ImageToSpeech.Properties.Resources.l_fondo;
            this.buttonLEER.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonLEER.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonLEER.Location = new System.Drawing.Point(122, 412);
            this.buttonLEER.Name = "buttonLEER";
            this.buttonLEER.Size = new System.Drawing.Size(121, 39);
            this.buttonLEER.TabIndex = 76;
            this.buttonLEER.Text = "Leer";
            this.buttonLEER.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonLEER.UseVisualStyleBackColor = true;
            this.buttonLEER.Click += new System.EventHandler(this.buttonLEER_Click);
            // 
            // buttonSEMICOLON
            // 
            this.buttonSEMICOLON.AccessibleDescription = "I";
            this.buttonSEMICOLON.AccessibleName = "I";
            this.buttonSEMICOLON.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonSEMICOLON.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.buttonSEMICOLON.Location = new System.Drawing.Point(162, 317);
            this.buttonSEMICOLON.Name = "buttonSEMICOLON";
            this.buttonSEMICOLON.Size = new System.Drawing.Size(24, 30);
            this.buttonSEMICOLON.TabIndex = 77;
            this.buttonSEMICOLON.Text = ";";
            this.buttonSEMICOLON.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonSEMICOLON.UseVisualStyleBackColor = true;
            this.buttonSEMICOLON.Click += new System.EventHandler(this.buttonSEMICOLON_Click);
            // 
            // buttonBORRAR
            // 
            this.buttonBORRAR.AccessibleDescription = "I";
            this.buttonBORRAR.AccessibleName = "I";
            this.buttonBORRAR.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonBORRAR.BackgroundImage = global::ImageToSpeech.Properties.Resources.l_fondo;
            this.buttonBORRAR.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonBORRAR.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonBORRAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBORRAR.Location = new System.Drawing.Point(17, 412);
            this.buttonBORRAR.Name = "buttonBORRAR";
            this.buttonBORRAR.Size = new System.Drawing.Size(99, 39);
            this.buttonBORRAR.TabIndex = 78;
            this.buttonBORRAR.Text = "Borrar";
            this.buttonBORRAR.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonBORRAR.UseVisualStyleBackColor = true;
            this.buttonBORRAR.Click += new System.EventHandler(this.buttonBORRAR_Click);
            // 
            // buttonSPACE
            // 
            this.buttonSPACE.AccessibleDescription = "I";
            this.buttonSPACE.AccessibleName = "I";
            this.buttonSPACE.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonSPACE.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSPACE.Location = new System.Drawing.Point(18, 361);
            this.buttonSPACE.Name = "buttonSPACE";
            this.buttonSPACE.Size = new System.Drawing.Size(137, 39);
            this.buttonSPACE.TabIndex = 79;
            this.buttonSPACE.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonSPACE.UseVisualStyleBackColor = true;
            this.buttonSPACE.Click += new System.EventHandler(this.buttonSPACE_Click);
            // 
            // buttonCOLON
            // 
            this.buttonCOLON.AccessibleDescription = "I";
            this.buttonCOLON.AccessibleName = "I";
            this.buttonCOLON.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonCOLON.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.buttonCOLON.Location = new System.Drawing.Point(193, 317);
            this.buttonCOLON.Name = "buttonCOLON";
            this.buttonCOLON.Size = new System.Drawing.Size(24, 30);
            this.buttonCOLON.TabIndex = 80;
            this.buttonCOLON.Text = ":";
            this.buttonCOLON.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonCOLON.UseVisualStyleBackColor = true;
            this.buttonCOLON.Click += new System.EventHandler(this.buttonCOLON_Click);
            // 
            // buttonInicio
            // 
            this.buttonInicio.AccessibleDescription = "I";
            this.buttonInicio.AccessibleName = "I";
            this.buttonInicio.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.buttonInicio.BackgroundImage = global::ImageToSpeech.Properties.Resources.l_fondo;
            this.buttonInicio.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonInicio.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonInicio.Location = new System.Drawing.Point(107, 2);
            this.buttonInicio.Name = "buttonInicio";
            this.buttonInicio.Size = new System.Drawing.Size(79, 30);
            this.buttonInicio.TabIndex = 81;
            this.buttonInicio.Text = "Inicio";
            this.buttonInicio.UseVisualStyleBackColor = true;
            this.buttonInicio.Click += new System.EventHandler(this.buttonInicio_Click);
            // 
            // FormComunicaPlus
            // 
            this.AcceptButton = this.buttonLEER;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGreen;
            this.CancelButton = this.buttonBORRAR;
            this.ClientSize = new System.Drawing.Size(291, 511);
            this.Controls.Add(this.buttonInicio);
            this.Controls.Add(this.buttonCOLON);
            this.Controls.Add(this.buttonSPACE);
            this.Controls.Add(this.buttonBORRAR);
            this.Controls.Add(this.buttonSEMICOLON);
            this.Controls.Add(this.buttonLEER);
            this.Controls.Add(this.buttonRIGHTEXCL);
            this.Controls.Add(this.buttonLEFTEXCL);
            this.Controls.Add(this.buttonRIGHTQUEST);
            this.Controls.Add(this.buttonLEFTQUEST);
            this.Controls.Add(this.buttonCOMMA);
            this.Controls.Add(this.buttonDOT);
            this.Controls.Add(this.textBox);
            this.Controls.Add(this.buttonZ);
            this.Controls.Add(this.buttonY);
            this.Controls.Add(this.buttonX);
            this.Controls.Add(this.buttonW);
            this.Controls.Add(this.buttonV);
            this.Controls.Add(this.buttonT);
            this.Controls.Add(this.buttonS);
            this.Controls.Add(this.buttonR);
            this.Controls.Add(this.buttonQ);
            this.Controls.Add(this.buttonP);
            this.Controls.Add(this.buttonÑ);
            this.Controls.Add(this.buttonN);
            this.Controls.Add(this.buttonM);
            this.Controls.Add(this.buttonL);
            this.Controls.Add(this.buttonK);
            this.Controls.Add(this.buttonJ);
            this.Controls.Add(this.buttonH);
            this.Controls.Add(this.buttonG);
            this.Controls.Add(this.buttonF);
            this.Controls.Add(this.buttonD);
            this.Controls.Add(this.buttonC);
            this.Controls.Add(this.buttonB);
            this.Controls.Add(this.button0);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.buttonU);
            this.Controls.Add(this.buttonO);
            this.Controls.Add(this.buttonI);
            this.Controls.Add(this.buttonE);
            this.Controls.Add(this.buttonA);
            this.Controls.Add(this.buttonAtras);
            this.Controls.Add(this.buttonAveces);
            this.Controls.Add(this.buttonNo);
            this.Controls.Add(this.buttonSi);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormComunicaPlus";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Panel COMUNICA +";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormComunicaPlus_FormClosed);
            this.Load += new System.EventHandler(this.FormComunicaPlus_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonAveces;
        private System.Windows.Forms.Button buttonNo;
        private System.Windows.Forms.Button buttonSi;
        private System.Windows.Forms.Button buttonAtras;
        private System.Windows.Forms.Button buttonA;
        private System.Windows.Forms.Button buttonE;
        private System.Windows.Forms.Button buttonI;
        private System.Windows.Forms.Button buttonO;
        private System.Windows.Forms.Button buttonU;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button0;
        private System.Windows.Forms.Button buttonG;
        private System.Windows.Forms.Button buttonF;
        private System.Windows.Forms.Button buttonD;
        private System.Windows.Forms.Button buttonC;
        private System.Windows.Forms.Button buttonB;
        private System.Windows.Forms.Button buttonM;
        private System.Windows.Forms.Button buttonL;
        private System.Windows.Forms.Button buttonK;
        private System.Windows.Forms.Button buttonJ;
        private System.Windows.Forms.Button buttonH;
        private System.Windows.Forms.Button buttonR;
        private System.Windows.Forms.Button buttonQ;
        private System.Windows.Forms.Button buttonP;
        private System.Windows.Forms.Button buttonÑ;
        private System.Windows.Forms.Button buttonN;
        private System.Windows.Forms.Button buttonW;
        private System.Windows.Forms.Button buttonV;
        private System.Windows.Forms.Button buttonT;
        private System.Windows.Forms.Button buttonS;
        private System.Windows.Forms.Button buttonZ;
        private System.Windows.Forms.Button buttonY;
        private System.Windows.Forms.Button buttonX;
        private System.Windows.Forms.TextBox textBox;
        private System.Windows.Forms.Button buttonDOT;
        private System.Windows.Forms.Button buttonCOMMA;
        private System.Windows.Forms.Button buttonLEFTQUEST;
        private System.Windows.Forms.Button buttonRIGHTQUEST;
        private System.Windows.Forms.Button buttonLEFTEXCL;
        private System.Windows.Forms.Button buttonRIGHTEXCL;
        private System.Windows.Forms.Button buttonLEER;
        private System.Windows.Forms.Button buttonSEMICOLON;
        private System.Windows.Forms.Button buttonBORRAR;
        private System.Windows.Forms.Button buttonSPACE;
        private System.Windows.Forms.Button buttonCOLON;
        private System.Windows.Forms.Button buttonInicio;
    }
}